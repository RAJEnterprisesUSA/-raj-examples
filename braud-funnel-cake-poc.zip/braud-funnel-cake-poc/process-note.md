# Process Note: Braud's Funnel Cake Cafe — Proof of Concept

## What this is
A single homepage design (hero, story, menu teaser, CTA) built specifically around the
real business: Braud's Funnel Cake Cafe, Town Square Mall, Las Vegas, family-owned since
2006, 4.3 stars / 132+ reviews, award-winning sweet and savory funnel cakes. No invented
facts: every claim (rating, location, hours, menu items and prices, "brings the fair to
Town Square") is pulled from the current live site, Yelp, and Facebook listing, not
guessed. The current site was reviewed first and is a generic template with one hero
image and an order button; this concept gives the same business real character.

## Tools actually used
- Web research (business's own site, Yelp, Facebook) to ground every fact used in copy
- AI image generation for two original concept photos (a plated funnel cake shot and a
  carnival-style storefront concept), since no real photography was supplied
- AI video generation (Veo 3.1) for a short looping hero background video, a slow-motion
  caramel pour over a funnel cake, matching what their current live site already does
  with a background video in its hero (a scoop of ice cream). This isn't just parity:
  the motion is tied to an actual product moment, not a generic stock loop
- Hand-built HTML/CSS for the homepage itself: pastel pink/cream/light-blue palette,
  rounded playful typography, hairline dashed dividers styled like carnival bunting,
  hover/scroll motion, fully responsive from mobile to desktop
- Playwright (headless browser automation) to record a real screen capture of the actual
  page scrolling, the actual hero video playing, and the actual hover states, not an
  AI-generated approximation of what the site might look like
- ffmpeg to assemble the walkthrough video (title card, screen recording, end card) and
  produce the desktop/mobile screenshots

## v2 additions (this pass)
Two new things were added, both real and functional, not decorative:
- **Live open/closed status in the hero.** Computed in the visitor's own browser against
  Braud's actual published hours (Mon-Thu 11-9, Fri-Sat 11-10, Sun 11-8, Yelp-verified).
  Not a static "open now" claim, it recalculates every page load.
- **Signature interactive element: a real funnel cake builder.** Visitors pick a base
  (Plain Jane Powder, Cinnamon, Chocolate, Nutella) and stack toppings; the price total
  computes live from Braud's actual published menu numbers, no fabricated pricing. Fully
  keyboard-operable (tested with Tab + Enter, not just mouse clicks), reduced-motion safe,
  and degrades to a working state with a `<noscript>` message if JavaScript is off. Every
  number was verified with an automated test, not eyeballed: e.g. Chocolate ($12) + vanilla
  ice cream ($2.50) + caramel drizzle ($1) + mixed nuts ($1.50) correctly totals $17.00,
  and removing a topping correctly subtracts.
- A real mobile layout bug was introduced by the new nav link and caught before delivery:
  the four nav items no longer fit at narrow widths, causing horizontal overflow. Fixed by
  hiding secondary nav links under 760px width (the Order Now button always stays visible)
  and re-verified with an automated overflow check across the page, not a visual guess.

## What's real vs. simulated, stated plainly
- The homepage code is real and running (openable in any browser). The hero background is
  now a real, generated video (not a static photo), looping a slow-motion caramel pour
- The walkthrough video is a genuine screen recording of that real page, including the
  hero video actually playing, not an AI video generation of an imagined site. This was
  a deliberate choice: for showing "how the page looks and feels live," an actual
  recording of the actual scroll/hover/video behavior is more honest and more useful than
  a generated approximation
- The two still photos and the hero video are AI-generated concept media, not real footage
  of Braud's actual food or storefront. They're placeholders showing the art direction; a
  full build would use the client's real product photography and a real filmed hero clip
  (Yelp alone has 199 real photos available), not AI-generated media, for anything
  client-facing at delivery
- Menu items, prices, and the reviews stat are real and current as of this research

## Time spent
Roughly 45 minutes end to end: business research, copy/content decisions grounded in real
facts, HTML/CSS build, image generation, screenshot capture, and video assembly.

## What a full multi-page build would look like from here
Following the same process used for other rebuilds (discovery, research, strategy,
sitemap, brand system, build, three real QA passes with tooling evidence, handoff docs):
roughly 8-12 pages (home, full menu, our story/about, catering, locations/hours, contact,
FAQ), a real photography plan (shot list for the client's own photographer, since this
business has real product and storefront to shoot), a proper brand style guide, and a
measurement plan. Timeline: 1-2 weeks for a build of this depth and QA rigor, given
research, three refinement passes, and handoff documentation are all real, non-skippable
steps, not padding. Cost: comparable to the $20K-tier scope discussed in prior work,
scaled to what this business's actual size and page count justify, not a fixed number
quoted before scoping the real business's actual page and feature needs with the owner.
